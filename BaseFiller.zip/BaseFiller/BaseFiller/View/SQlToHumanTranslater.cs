﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseFiller.View
{
    class SQlToHumanTranslater
    {
        private static Dictionary<string, string> dictionary;
        static SQlToHumanTranslater()
        {
            dictionary = new Dictionary<string, string>();
           
        }
        public string Translate(string sql)
        {
            //PCUser PcManufacturer Units Users Departaments ResponsiblePerson MonitorManufacturers MonitorModels CpuManufacturer GpuModel GpuManufacturer RamManufacturer RamType Ram HddManufacturer Hdd MotherboardManufacturers RepairsType RepairsStatus Motherboards Posts RepairsHistory OS OsReplaceHistory PcConfiguration CpuModel PC PcMonitors Monitors Modernization Laptops
            dictionary.Add("PCUser",)
            PCUser
            return "";
        }
        
    }
}
